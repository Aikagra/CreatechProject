package com.example.techknights.Model;

public class AllMethods
{
    public static String name = "";
}
